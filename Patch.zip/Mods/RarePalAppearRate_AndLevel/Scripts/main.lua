--Rate Appearance
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.RarePal_AppearanceProbability = 10.0
end)
-- Level multipler 
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.RarePal_LevelMultiply = 30.0
end)