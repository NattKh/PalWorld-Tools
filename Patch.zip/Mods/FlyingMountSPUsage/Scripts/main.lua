
--Mount Flying SP Cost
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.FlyMaxHeight = 999999
end)
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.FlyHover_SP = 0
end)
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.FlyHorizon_SP = 0
end)
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.FlyHorizon_Dash_SP = 0
end)
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.FlyVertical_SP = 0
end)
--Mount Flying SP Cost
