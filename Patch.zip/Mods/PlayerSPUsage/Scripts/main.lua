--Player SP COST
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.SprintSP = 0
end)
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.GliderSP = 0 --don't work for some reason.
end)
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.Swimming_SP_Swim = 0
end)
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.MeleeAttackSP = 0
end)
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.JumpSP = 0
end)
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.StepSP = 0
end)
--Player SP COST