
--random testing
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.BuildingProgressInterpolationSpeed = 1000
end)
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.AimingSpeedRateInRide = 100
end)
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.WorkerCollectResourceStackMaxNum = 100
end)
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.BuildObj_HatchedPalCharacterLevel = 100
end)
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.AddWorkSpeedPerStatusPoint = 1000
end)
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.BuildingMaxZ = 999999
end)
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.VisitorNPCProbability = 100
end)
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.PalRotateSpeedToWork = 100
end)
--random testing

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.StatusCalculate_TribeMultiply_CraftSpeed = 100
end)

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.CharacterMaxRank = 100
end)
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.OtomoLevelSyncAddMaxLevel = 100
end)
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.OtomoSlotNum = 100
end)
NotifyOnNewObject("/Script/Pal.PalUtility", function(PalUtility)
PalUtility.GetDebugBotBaseCampWorkerCount = 100
end)
NotifyOnNewObject("/Script/Pal.PalBaseCampFacilityCountPair", function(FPalBaseCampFacilityCountPair)
FPalBaseCampFacilityCountPair.FacilityCount = 100
end)
NotifyOnNewObject("/Script/Pal.FPalBaseCampLevelMasterData", function(FPalBaseCampLevelMasterData)
FPalBaseCampLevelMasterData.WorkerMaxNum = 100
end)
NotifyOnNewObject("/Script/Pal.FPalOptionWorldStaticSettings", function(FPalOptionWorldStaticSettings)
FPalOptionWorldStaticSettings.BaseCampWorkerMaxNum = 100
end)
NotifyOnNewObject("/Script/Pal.FPalOptionWorldStaticSettings", function(FPalOptionWorldStaticSettings)
FPalOptionWorldStaticSettings.PalEggDefaultHatchingTime = 0
end)
NotifyOnNewObject("/Script/Pal.FPalOptionWorldStaticSettings", function(FPalOptionWorldStaticSettings)
FPalOptionWorldStaticSettings.PalCaptureRate = 100
end)
NotifyOnNewObject("/Script/Pal.FPalOptionWorldSettings", function(FPalOptionWorldSettings)
FPalOptionWorldSettings.BaseCampMaxNum = 100
end)
NotifyOnNewObject("/Script/Pal.FPalOptionWorldSettings", function(FPalOptionWorldSettings)
FPalOptionWorldSettings.BaseCampWorkerMaxNum = 100
end)

NotifyOnNewObject("/Script/Pal.FPalOptionWorldSettings", function(EPalOptionWorldDifficulty)
EPalOptionWorldDifficulty.BaseCampWorkerMaxNum = 100
EPalOptionWorldDifficulty.BaseCampMaxNum = 100
end)
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.BaseCampWorkerMaxNum = 100
PalGameSetting.BaseCampMaxNum = 100
PalGameSetting.WorkerMaxNum = 100
end)