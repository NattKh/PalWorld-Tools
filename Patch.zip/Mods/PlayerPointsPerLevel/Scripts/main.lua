--Level up modifier
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.technologyPointPerLevel = 50
end)
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.StatusPointPerLevel = 50
end)
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
PalGameSetting.TechnologyPoint_UnlockFastTravel = 10
end)
--Level up modifier